package com.cg.bank.dao;



import java.sql.SQLException;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public interface BankDAO {
	
	public void addCustomer(Customer c) throws ClassNotFoundException, SQLException;
	public void addAccount(Account a) throws ClassNotFoundException, SQLException;
	public Account deposit(Long accno,double balance) throws ClassNotFoundException, SQLException;
	public Account withDraw(Long accno,double balance) throws ClassNotFoundException, SQLException;
	public Account showBalance(long accNo) throws ClassNotFoundException, SQLException;
	public Account fundTransfer(Account acc) throws ClassNotFoundException, SQLException;


}

package com.cg.bank.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.cg.bank.JDBC.JDBCUtil;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;


public class BankDAOImpl implements BankDAO {

	@Override
	public void addCustomer(Customer c) throws ClassNotFoundException, SQLException{
		Connection con=JDBCUtil.connect();
		Statement stmt =con.createStatement();
		PreparedStatement pst =con.prepareStatement("INSERT INTO Customer_detail VALUES(?,?,?,?)");
		pst.setLong(1,c.getCustomeraccno());
		pst.setString(2, c.getCustomername() );
		pst.setString(3, c.getCustomermobileno());
		pst.setString(4, c.getCustomeraddress());
		pst.executeUpdate();
	}

	@Override
	public void addAccount(Account a) throws ClassNotFoundException, SQLException{
		Connection con=JDBCUtil.connect();
		Statement stmt =con.createStatement();
		PreparedStatement pst =con.prepareStatement("INSERT INTO Account_detail VALUES(?,?,?)");
		pst.setLong(1, a.getAccountno());
		pst.setString(2, a.getAccounttype());
		pst.setDouble(3, a.getBalance());
		pst.executeUpdate();
		
	}

	@Override
	public Account deposit(Long accno, double balance) throws ClassNotFoundException, SQLException{
		Connection con=JDBCUtil.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("update Account_detail set accountbalance='"+balance+"'where accountno='"+accno+"'");
		return null;
	}

	@Override
	public Account withDraw(Long accno, double balance) throws ClassNotFoundException, SQLException{
		Connection con=JDBCUtil.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("update Account_detail set accountbalance='"+balance+"'where accountno='"+accno+"'");
		
		return null;
	}

	

	

	@Override
	public Account showBalance(long accNo) throws ClassNotFoundException, SQLException{
		Connection con=JDBCUtil.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("select * from Account_detail where accountno= "+accNo+" ");
		while(res.next())
		{
		long accno=res.getLong(1);
		String type=res.getString(2);
		double balance=res.getDouble(3);
		Account account=new Account(accno,type,balance);
		return account;
	}
		return null;
	}

	@Override
	public Account fundTransfer(Account acc) throws ClassNotFoundException, SQLException{
		Connection con=JDBCUtil.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("update Account_detail set accountbalance='"+acc.getBalance()+"' where Accountno='"+acc.getAccountno()+"'");
		
		return acc;
	}

}

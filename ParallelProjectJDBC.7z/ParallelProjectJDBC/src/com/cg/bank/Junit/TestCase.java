package com.cg.bank.Junit;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import com.cg.bank.dao.BankDAO;
import com.cg.bank.dao.BankDAOImpl;
import com.cg.bank.entity.Account;

class TestCase {
	static BankDAO dao=new BankDAOImpl();

	@Test
	void testDeposit() throws ClassNotFoundException, SQLException {
		Account acc=dao.deposit( (long) 15010300, 20000);
		double bal=acc.getBalance();
		assertEquals(22000,bal+2000);
	}

	@Test
	void testWithDraw() throws ClassNotFoundException, SQLException {
		Account acc=dao.withDraw( (long) 15010300, 10000);
		double bal=acc.getBalance();
		assertEquals(18000,bal-2000);
	}

	@Test
	void testShowBalance() throws ClassNotFoundException, SQLException {
		Account acc=dao.showBalance( 15010300);
		double bal=acc.getBalance();
		assertEquals(20000,bal);
		
		
	}
	

}

package com.cg.bank.UI;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.BankException;
import com.cg.bank.service.BankService;
import com.cg.bank.service.BankServiceImpl;



public class RunMain {
	
	static Scanner sc=null;
	static BankService service=null;
	private static double balance;
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		 sc=new Scanner(System.in);
		   service=new BankServiceImpl();
			int choice=0;
			while(true)
			{
				System.out.println("Welcome to xyz bank");
				System.out.println("1:Create an account\t 2:To show the balance of account\n");
				System.out.println("3:Deposit\t 4:To withdraw Amount\n");
				System.out.println("5:For FundTransfer\n");
				System.out.println("6:EXIT");
				System.out.println("Enter Your Choice");
				choice=sc.nextInt();
				switch(choice)
				{
				case 1:
					createAccount();
					break;
				case 2:
					showBalance();
					break;
				case 3:
					deposit();
					break;
				case 4:
					withdraw();
					break;
				case 5:
					fundTransfer();
					break;
				
				default:
					break;
				}
				
			}
		}

	private static void createAccount() throws ClassNotFoundException, SQLException {
		System.out.println("enter the customername:");
		String customername=sc.next();
		try
		{
		if(service.validateCustomerName(customername))
		{
			
		
				System.out.println("enter the customer mobile number");
				String number=sc.next();
				try
				{
				if(service.validateNumber(number))
				{
					System.out.println("enter the customer address");
					String address=sc.next();
					System.out.println("Minimum balance to be deposited to create an account");
					double amount=sc.nextDouble();
					System.out.println("enter the account type");
					String type=sc.next();
					if(amount>3000)
					{
					long accno=(long)(Math.round(Math.random()*10000000+10000000));
					System.out.println(" account created sucessfully"+" "+"account number generated"+" "+accno);
				    Account acc=new Account(accno,type,amount);
				    service.addAccount(acc);
				    Customer cus=new Customer(accno,address,number,customername);
				    service.addCustomer(cus);
					}
					else{
						System.out.println("Minimum amount should be 3000 to create account");
					}
					
				}
			}catch(BankException e){
				
			}
		}
		}catch(BankException e){
			
		}

	
	
		
		
		
	}

	private static void showBalance() throws ClassNotFoundException, SQLException {
		System.out.println("Enter AccountNo to get Balance");
		long accno=sc.nextLong();
		String accNo1=String.valueOf(accno);
		try {
		if(service.validateAccountno(accNo1)==true)
		{
			
			
	     Account account=service.showBalance(accno);
		double balance=account.getBalance();
		System.out.println("Balance in the Account:"+ balance);
		
		}
			else
			{
				throw new BankException(accNo1);
			}
		}catch(BankException e)
			{
				e.getStackTrace();
			}
		}
	
	private static void deposit() throws ClassNotFoundException, SQLException {
		System.out.println("Enter the AccountNo");
		long accno=sc.nextLong();
		String accNo1=String.valueOf(accno);
        try {
		if(service.validateAccountno(accNo1)==true)
			
		{
			Account account=service.showBalance(accno);
			double balance=account.getBalance();
			System.out.println("your Account balance is : "+balance);
			System.out.println("Enter Amount to be Deposited");
			double amount=sc.nextDouble();
		   
			
			double balance1=balance+amount;
			 Account acc=service.deposit(accno,balance1);
			 
			 String type = "savings";
			Account acc1=new Account(accno,type,balance1);
			
			System.out.println("Amount Succesfully Deposited:"+acc1);
			
		}
		else
		{
			throw new BankException(accNo1);
		}
	}catch(BankException e)
		{
			e.getStackTrace();
		}
	}

	private static void withdraw() throws ClassNotFoundException, SQLException {
		System.out.println("Enter the AccountNo");
		long accno=sc.nextLong();
		String accNo1=String.valueOf(accno);
        try {
		if(service.validateAccountno(accNo1)==true)
			
		{
			Account account=service.showBalance(accno);
			double balance=account.getBalance();
			System.out.println("your Account balance is : "+balance);
			System.out.println("Enter Amount to be Withdrawn");
			double amount=sc.nextDouble();
		   
			
			double balance1=balance-amount;
			 Account acc=service.withDraw(accno,balance1);
			 
			 String type = "savings";
			Account acc1=new Account(accno,type,balance1);
			
			System.out.println("Amount Succesfully Withdrawn:"+acc1);
			
		}
		else
		{
			throw new BankException(accNo1);
		}
	}catch(BankException e)
		{
			e.getStackTrace();
		}
		
	}

	private static void fundTransfer() throws ClassNotFoundException, SQLException {
		System.out.println("Enter the Sender AccountNo");
		long accNo1=sc.nextLong();
		
		System.out.println("Enter the reciepent AccountNo");
		long accNo2= sc.nextLong();
		String accNo3=String.valueOf(accNo1);
		String accNo4=String.valueOf(accNo2);
		try {
		if((service.validateAccountno(accNo3)==true)&&(service.validateAccountno(accNo4)==true))
		{
			
			System.out.println("Enter Amount to be Transfer");
			double amount=sc.nextDouble();
		
			
				Account a=service.showBalance(accNo1);
				
			double bal1=a.getBalance();
			
			if(amount<(bal1-500))
			{
				
			
				
				bal1-=amount;
			    String type = "savings";
			Account account1=new Account(accNo1,type,bal1);
			Account a2=service.showBalance(accNo2);
			double bal2=a2.getBalance();
			
			bal2+=amount;
				Account account2=new Account(accNo2,type,bal2);
				Account acc=service.fundTransfer(account1);
				Account acc1=service.fundTransfer(account2);
				System.out.println("Amount is Successfully Transfered");
				System.out.println("Amount balance in Sender:"+bal1);
				System.out.println("Amount balance in reciepent:"+bal2);
			}
		}else
		{
			throw new BankException(accNo3);
		}
	}catch(BankException e)
		{
		e.getStackTrace();
		}
		
	}
	
}

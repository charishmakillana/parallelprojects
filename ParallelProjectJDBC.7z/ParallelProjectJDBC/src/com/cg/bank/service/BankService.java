package com.cg.bank.service;



import java.sql.SQLException;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.BankException;


public interface BankService {
	
	public void addCustomer(Customer c) throws ClassNotFoundException, SQLException;
	public void addAccount(Account a) throws ClassNotFoundException, SQLException;
	public Account deposit(Long accno,double balance) throws ClassNotFoundException, SQLException;
	public Account withDraw(Long accno,double balance) throws ClassNotFoundException, SQLException;
	boolean validateCustomerName(String customername) throws BankException;
	boolean validateNumber(String number) throws BankException;
	boolean validateAccountno(String accno) throws BankException;
	
	public Account showBalance(long accNo) throws ClassNotFoundException, SQLException;
	public Account fundTransfer(Account acc) throws ClassNotFoundException, SQLException;


}

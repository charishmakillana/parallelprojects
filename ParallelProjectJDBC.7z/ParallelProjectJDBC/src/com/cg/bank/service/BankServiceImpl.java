package com.cg.bank.service;


import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bank.dao.BankDAO;
import com.cg.bank.dao.BankDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.BankException;

public class BankServiceImpl implements BankService {
  
	BankDAO dao=new BankDAOImpl();
	
	@Override
	public void addCustomer( Customer c) throws ClassNotFoundException, SQLException{
		 dao.addCustomer( c);
		
	}

	@Override
	public void addAccount(Account a) throws ClassNotFoundException, SQLException{
		 dao.addAccount(a);
		
	}

	@Override
	public Account deposit(Long accno, double balance) throws ClassNotFoundException, SQLException{
		return dao.deposit(accno, balance);
		
	}

	@Override
	public Account withDraw(Long accno, double balance) throws ClassNotFoundException, SQLException{
		return dao.withDraw(accno, balance);
		
	}

	@Override
	public boolean validateCustomerName(String customername) throws BankException {
		Pattern p=Pattern.compile("[A-Z]{1}[a-z]{1,9}");
		Matcher m=p.matcher(customername);
		if(m.matches())
		{
			return true;
		}
		else
			
			System.out.println("enter valid name");
		return false;
		
	}

	@Override
	public boolean validateNumber(String number) throws BankException {
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(number);
		if(m.matches())
		{
			return true;
		}
		else
			
			System.out.println("enter valid number");
		return false;
	}

	@Override
	public boolean validateAccountno(String accno) throws BankException {
		Pattern p=Pattern.compile("[0-9]{8,11}");
		Matcher m=p.matcher(accno);
		if(m.matches())
		{
			return true;
		}
		else
		
			System.out.println("enter valid accno");
		return false;
	}


	@Override
	public Account showBalance(long accNo) throws ClassNotFoundException, SQLException{
		Account a=dao.showBalance(accNo);
		return a;
		
	}

	@Override
	public Account fundTransfer(Account acc) throws ClassNotFoundException, SQLException{
		return dao.fundTransfer(acc);
		
	}

}

package com.cg.bank.exception;

public class BankException extends Exception{

	public BankException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	

}

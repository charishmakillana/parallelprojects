package com.cg.bank.entity;

public class Account {
	private long accountno;
	private String accounttype;
	private double balance;
	
	
	public Account(long accountno, String accounttype, double balance) {
		super();
		this.accountno = accountno;
		this.accounttype = accounttype;
		this.balance = balance;
	}
	public long getAccountno() {
		return accountno;
	}
	public void setAccountno(long accountno) {
		this.accountno = accountno;
	}
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accountno=" + accountno + ", accounttype=" + accounttype + ", balance=" + balance + "]";
	}
	
	

}

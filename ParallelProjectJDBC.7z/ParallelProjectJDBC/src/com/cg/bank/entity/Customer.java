package com.cg.bank.entity;

public class Customer {
	
	private long customeraccno;
	private String customeraddress;
	private String customermobileno;
	private String customername;
	public Customer(long customeraccno, String customeraddress, String customermobileno, String customername) {
		super();
		this.customeraccno = customeraccno;
		this.customeraddress = customeraddress;
		this.customermobileno = customermobileno;
		this.customername = customername;
	}
	public long getCustomeraccno() {
		return customeraccno;
	}
	public void setCustomeraccno(long customeraccno) {
		this.customeraccno = customeraccno;
	}
	public String getCustomeraddress() {
		return customeraddress;
	}
	public void setCustomeraddress(String customeraddress) {
		this.customeraddress = customeraddress;
	}
	public String getCustomermobileno() {
		return customermobileno;
	}
	public void setCustomermobileno(String customermobileno) {
		this.customermobileno = customermobileno;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	@Override
	public String toString() {
		return "Customer [customeraccno=" + customeraccno + ", customeraddress=" + customeraddress
				+ ", customermobileno=" + customermobileno + ", customername=" + customername + "]";
	}
	
	

}

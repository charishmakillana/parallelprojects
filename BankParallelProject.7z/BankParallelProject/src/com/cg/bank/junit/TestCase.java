package com.cg.bank.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.bank.dao.BankDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.exception.BankException;

class TestCase {
	static BankDAOImpl dao=new BankDAOImpl();

	@Test
	void testDeposit() throws BankException{
		Account acc=dao.deposit(33678546789l, 20000);
		double bal=acc.getBalance();
		assertEquals(22000,bal+2000);
	}

	@Test
	void testWithDraw() {
		Account acc=dao.withDraw(33678546789l, 20000);
		double bal=acc.getBalance();
		assertEquals(18000,bal-2000);
		
		
	}

	@Test
	void testShowBalance() {
		Account acc=dao.showBalance(33678546789l);
		double bal=acc.getBalance();
		assertEquals(20000,bal);
	}

	@Test
	void testFundTransfer() {
		Account acc=dao.fundTransfer(new Account("savings a/c",20000,33678546789l));
		double bal=acc.getBalance();
		assertEquals(18000,bal-2000);
		Account acc1=dao.fundTransfer(new Account("savings a/c",30000,33678556799l));
		double bal1=acc1.getBalance();
		assertEquals(32000,bal1+2000);
	}

}

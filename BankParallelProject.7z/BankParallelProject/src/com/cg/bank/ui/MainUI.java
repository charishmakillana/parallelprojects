package com.cg.bank.ui;


import java.util.HashMap;
import java.util.Scanner;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.BankException;
import com.cg.bank.service.BankService;
import com.cg.bank.service.BankServiceImpl;


public class MainUI {
	static Scanner sc=null;
	static BankService bankService=null;
	private static double balance;
	
	public static void main(String[] args) throws BankException {
		sc=new Scanner(System.in);
		bankService=new BankServiceImpl();
		int choice=0;
		while(true)
		{
			System.out.println("Welcome to xyz bank");
			System.out.println("1:Create an account\t 2:To show the balance of account\n");
			System.out.println("3:Deposit\t 4:To withdraw Amount\n");
			System.out.println("5:For FundTransfer\n");
			System.out.println("6:EXIT");
			System.out.println("Enter Your Choice");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				createAccount();
				break;
			case 2:
				showBalance();
				break;
			case 3:
				deposit();
				break;
			case 4:
				withdraw();
				break;
			case 5:
				fundTransfer();
				break;
			
			default:
				break;
			}
			
		}
	}

	private static void createAccount() throws BankException{

		System.out.println("enter the customername:");
		String customername=sc.next();
		try
		{
		if(bankService.validateCustomerName(customername))
		{
			
		
				System.out.println("enter the customer mobile number");
				String number=sc.next();
				try
				{
				if(bankService.validateNumber(number))
				{
					System.out.println("enter the customer address");
					String address=sc.next();
					System.out.println("Minimum balance to be deposited to create an account");
					double amount=sc.nextDouble();
					System.out.println("enter the account type");
					String type=sc.next();
					if(amount>3000)
					{
					long accno=(long)(Math.round(Math.random()*10000000+10000000));
					System.out.println(" account created sucessfully"+" "+"account number generated"+" "+accno);
				    Account acc=new Account(type,amount,accno);
				    bankService.addAccount(accno, acc);
				    Customer cus=new Customer(customername,accno,number,address);
				    bankService.addCustomer(accno, cus);
					}
					else{
						System.out.println("Minimum amount should be 3000 to create account");
					}
					
				}
			}catch(BankException e){
				
			}
		}
		}catch(BankException e){
			
		}

	
	

	}
		
		

		public static void showBalance()
		{
			System.out.println("Enter AccountNo to get Balance");
			long accno=sc.nextLong();
			String accNo1=String.valueOf(accno);
			try {
			if(bankService.validateAccountno(accNo1)==true)
			{
				HashMap<Long, Account> map=bankService.fetchAccount();
				try {
				if(map.containsKey(accno))
				{
				
		     Account account=bankService.showBalance(accno);
			double balance=account.getBalance();
			System.out.println("Balance in the Account:"+ balance);
			
			}
				else
				{
					throw new BankException(accno);
				}}catch(BankException e)
				{
					e.getStackTrace();
				}
			}
				
			else
			{
				throw new BankException(accno);
			}
		}catch(BankException e)
			{
			e.getStackTrace();
			}
		}

	private static void deposit() throws BankException {
			System.out.println("Enter the AccountNo");
			long accNo=sc.nextLong();
			String accNo1=String.valueOf(accNo);
			if(bankService.validateAccountno(accNo1)==true)
				
			{
				HashMap<Long, Account> map=bankService.fetchAccount();
				try {
				if(map.containsKey(accNo))
				{
				System.out.println("Enter Amount to be Deposited");
				double amount=sc.nextDouble();
			    Account acc=bankService.deposit(accNo,balance);
				double balance1=acc.getBalance();
				double balance=balance1+amount;
				
				String type = "savings";
				Account acc1=new Account(type,balance, accNo);
				System.out.println("Amount Succesfully Deposited:"+acc1);
				
			}else
			{
				throw new BankException(accNo);
			}}catch(BankException e)
			{
				e.getStackTrace();
			}
			}
			else
			{
				System.out.println("Enter the valid AccountNo");
			}
			}
	private static void withdraw() {
		System.out.println("Enter your account number");
		Long accno=sc.nextLong();
		String accNo1=String.valueOf(accno);
		try {
		if(bankService.validateAccountno(accNo1)==true)
			
		{
			HashMap<Long, Account> map=bankService.fetchAccount();
			try {
			if(map.containsKey(accno))
			{
			System.out.println("Enter Amount to be Withdrawn");
			double amount=sc.nextDouble();
			Account acc=bankService.withDraw((accno),balance);
			double bal=acc.getBalance();
			if(amount<(bal-3000))
			{
				double balance=bal-amount;
				String type = "savings";
				Account acc1=new Account(type,balance,(accno));
				System.out.println("Amount Succesfully Withdrawn ");
				System.out.println("Account Balance:"+" "+balance);
				
			}
		}
			else
			{
				throw new BankException((accno));
			}}catch(BankException e)
			{
				e.getStackTrace();
			}
		}
		else
		{
			throw new BankException((accno));
		}
	}catch(BankException e)
		{
		e.getStackTrace();
		}
	}

	private static void fundTransfer() {
		System.out.println("Enter the Sender AccountNo");
		long accNo1=sc.nextLong();
		System.out.println("Enter the reciepent AccountNo");
		long accNo2= sc.nextLong();
		String accNo3=String.valueOf(accNo1);
		String accNo4=String.valueOf(accNo2);
		try {
		if((bankService.validateAccountno(accNo3)==true)&&(bankService.validateAccountno(accNo4)==true))
		{
			
			HashMap<Long, Account> map=bankService.fetchAccount();
			try {
			if(map.containsKey(accNo1)&&map.containsKey(accNo2))
			{
			System.out.println("Enter Amount to be Transfer");
			double amount=sc.nextDouble();
			
			Account a=bankService.showBalance(accNo1);
			double bal1=a.getBalance();
			
			if(amount<(bal1-500))
			{
				
				 bal1-=amount;
			    String type = "savings";
			Account account1=new Account(type,bal1,accNo1);
			Account a2=bankService.showBalance(accNo2);
			double bal2=a2.getBalance();
			bal2+=amount;
			Account account2=new Account(type,bal2, accNo2);
			Account acc=bankService.fundTransfer(account1);
			Account acc1=bankService.fundTransfer(account2);
				System.out.println("Amount is Successfully Transfered");
				System.out.println("Amount balance in Sender:"+bal1);
				System.out.println("Amount balance in reciepent:"+bal2);
			}
		}else
		{
			throw new BankException(accNo1);
		}
	}catch(BankException e)
		{
		e.getStackTrace();
		}
		}
		else
		{
			throw new BankException(accNo1);
		}
	}catch(BankException e)
		{
		e.getStackTrace();
		}
			
		
	}
		
		
		
	}


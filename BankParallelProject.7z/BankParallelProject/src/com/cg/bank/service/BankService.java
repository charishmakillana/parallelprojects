package com.cg.bank.service;

import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.BankException;

public interface BankService {
	public long addCustomer(Long accno,Customer c);
	public long addAccount(Long accno,Account a);
	public Account deposit(Long accno,double balance);
	public Account withDraw(Long accno,double balance);
	boolean validateCustomerName(String customername) throws BankException;
	boolean validateNumber(String number) throws BankException;
	boolean validateAccountno(String accno) throws BankException;
	public HashMap<Long, Account> fetchAccount();
	public Account showBalance(long accNo);
	public Account fundTransfer(Account accNo1);
	
	
}

package com.cg.bank.service;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bank.dao.BankDAO;
import com.cg.bank.dao.BankDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.BankException;

public class BankServiceImpl implements BankService {
	BankDAO bankdao=new BankDAOImpl();

	public long addCustomer(Long accno,Customer c)
	{
		bankdao.addCustomer(accno, c);
		return c.getCustomeraccountno();
	}
	@Override
	public long addAccount(Long accno, Account a) {
		bankdao.addAccount(accno, a);
		return a.getAccountno();
	}
	@Override
	public Account deposit(Long accno,double balance) {
		Account a=bankdao.deposit(accno,balance);
		return a;
	}
	@Override
	public Account withDraw(Long accno,double balance) {
		Account a=bankdao.withDraw(accno,balance);
		return a;
	}
	@Override
	public boolean validateCustomerName(String customername) throws BankException{
		Pattern p=Pattern.compile("[A-z]{1}[a-z]{1,9}");
		Matcher m=p.matcher(customername);
		if(m.matches())
		{
			return true;
		}
		else
			
			System.out.println("enter valid name");
			return false;
	}

	@Override
	public boolean validateNumber(String number) throws BankException{
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(number);
		if(m.matches())
		{
			return true;
		}
		else
			
			System.out.println("enter valid number");
			return false;
	}
	
	@Override
	public boolean validateAccountno(String accno) throws BankException{
		Pattern p=Pattern.compile("[0-9]{11}");
		Matcher m=p.matcher(accno);
		if(m.matches())
		{
			return true;
		}
		else
		
			System.out.println("enter valid accno");
			return false;
		
		
	}
	@Override
	public HashMap<Long, Account> fetchAccount() {
		HashMap<Long,Account> map=bankdao.fetchAccount();
		return map;
	}
	@Override
	public Account showBalance(long accNo) {
		Account account=bankdao.showBalance(accNo);
		return account;
		
	}
	
	@Override
	public Account fundTransfer(Account accNo1) {
		Account account=bankdao.fundTransfer(accNo1);
		return account;
	}
	


}

package com.cg.bank.util;

import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;


public class CollectionBank {
public static HashMap<Long,Account> accSet=new HashMap<Long,Account>();
	
	static
	{
		accSet.put(33678546789l,new Account("savings a/c",20000,33678546789l));
		accSet.put(33678556799l,new Account("savings a/c",30000,33678556799l));
		accSet.put(33678566777l,new Account("savings a/c",50000,33678566777l));
		accSet.put(33678577689l,new Account("savings a/c",10000,33678577689l));
		accSet.put(33678586796l,new Account("savings a/c",70000,33678586796l));
				
	}
	public static HashMap<Long,Customer> cusSet=new HashMap<Long,Customer>();
	
	static
	{
		cusSet.put(33678546789l, new Customer("Navya",33678546789l,"8555911861","Nellore"));
		cusSet.put(33678556799l, new Customer("Kavya",33678556799l,"9676329303","Chennai"));
		cusSet.put(33678566777l, new Customer("Divya",33678566777l,"8985271446","Bangalore"));
		cusSet.put(33678577689l, new Customer("Hema",33678577689l,"9742850852","Kerala"));
		cusSet.put(33678586796l, new Customer("Bindu",33678586796l,"912103037","Vizag"));
	}
	public static void addCustomer(Long accno,Customer c)
	{
		cusSet.put(accno, c);
	}
	public static void addAccount(Long accno,Account a)
	{
		accSet.put(accno, a);
	}
	public static Account deposit(Long accno,double balance) {
		return accSet.get(accno);
		
	}
	public static Account withdraw(Long accno,double balance) {
		return accSet.get(accno);
	}
	public static Account fundTransfer(Account accNo)
	{
		return accSet.get(accNo);
		
	}
	public static Account showBalance(long accNo)
	{
		return accSet.get(accNo);
		
	}
	public static HashMap<Long,Account> fetchAccount(){
		return accSet;
	}
	

}

package com.cg.bank.exception;

public class BankException extends Exception{

	public BankException(Long accNo) {
		
		// TODO Auto-generated constructor stub
	}
	

}

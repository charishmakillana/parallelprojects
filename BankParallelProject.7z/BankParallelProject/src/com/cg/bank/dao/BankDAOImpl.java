package com.cg.bank.dao;

import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.util.CollectionBank;

public class BankDAOImpl implements BankDAO {

	public long addCustomer(Long accno,Customer c)
	{
		CollectionBank.addCustomer(accno, c);
		return c.getCustomeraccountno();
	}
	public long addAccount(Long accno,Account a)
	{
		CollectionBank.addAccount(accno, a);
		return a.getAccountno();
	}
	public Account deposit(Long accno,double balance)
	{
		Account a=CollectionBank.deposit(accno,balance);
		return a;
	}
	public Account withDraw(Long accno,double balance)
	{
		Account a=CollectionBank.withdraw(accno,balance);
		return a;
	}
	@Override
	public Account showBalance(Long accNo) {
		Account account= CollectionBank.showBalance(accNo);
		return account;
	}
	@Override
	public Account fundTransfer(Account accno) {
		 CollectionBank.fundTransfer(accno);
		return accno;
	}
	@Override
	public  HashMap<Long,Account> fetchAccount()
	{
		HashMap<Long,Account> map=	CollectionBank.fetchAccount();
		return map;
	}
}

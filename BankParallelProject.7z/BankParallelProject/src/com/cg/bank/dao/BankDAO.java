package com.cg.bank.dao;

import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

public interface BankDAO {
	public long addCustomer(Long accno,Customer c);
	public long addAccount(Long accno,Account a);
	public Account deposit(Long accno,double balance);
	public Account withDraw(Long accno,double balance);
	public Account showBalance(Long accNo);
	public Account fundTransfer(Account accNo);
	HashMap<Long, Account> fetchAccount();
	
}

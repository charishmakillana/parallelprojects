package com.cg.bank.entity;

public class Customer {
	private  String customername;
	private long customeraccountno;
	private String mobileno;
	private String address;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String customername, long customeraccountno,
			String mobileno, String address) {
		super();
		this.customername = customername;
		this.customeraccountno = customeraccountno;
		this.mobileno = mobileno;
		this.address = address;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public long getCustomeraccountno() {
		return customeraccountno;
	}
	public void setCustomeraccountno(long customeraccountno) {
		this.customeraccountno = customeraccountno;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Customer [customername=" + customername
				+ ", customeraccountno=" + customeraccountno + ", mobileno="
				+ mobileno + ", address=" + address + "]";
	}
	
	
	

}

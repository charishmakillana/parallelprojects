package com.cg.bank.entity;

public class Account {
	private String accounttype;
	private double balance;
	private long accountno;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Account(String accounttype, double balance, long accountno) {
		super();
		this.accounttype = accounttype;
		this.balance = balance;
		this.accountno = accountno;
	}

	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public long getAccountno() {
		return accountno;
	}
	public void setAccountno(long accountno) {
		this.accountno = accountno;
	}
	@Override
	public String toString() {
		return "Account [accounttype=" + accounttype + ", balance=" + balance
				+ ", accountno=" + accountno + "]";
	}
	
	

}

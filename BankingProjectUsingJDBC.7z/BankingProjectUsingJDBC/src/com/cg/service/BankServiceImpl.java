package com.cg.service;

import java.sql.SQLException;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.bankException.BankException;
import com.cg.bean.Account;
import com.cg.dao.BankDAO;
import com.cg.dao.BankDAOImpl;

public class BankServiceImpl implements BankService {
	BankDAO dao=new BankDAOImpl();

	@Override
	public void validateName(String custName) throws BankException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (!Pattern.matches(nameRegEx, custName)) {
			throw new BankException("First letter should be capital and length must be in between 5 to 10");
		}
		
	}

	@Override
	public void validatePhoneno(String phoneno) throws BankException {
		String nameRegEx = "[7|8|9]{1}[0-9]{9}";
		if(!Pattern.matches(nameRegEx, phoneno)) {
			throw new BankException("mobile number should be 10 digits");
		}
	}

	@Override
	public void validateBranch(String branchname) throws BankException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (!Pattern.matches(nameRegEx, branchname)) {
			throw new BankException("Please Enter valid branch name ");
		}
		
	}


	@Override
	public void addCustomer(int accountnumber, Account account)
			throws BankException, ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		dao.addCustomer(accountnumber,account);

		
	}

	@Override
	public Account showBalance(int number) throws BankException, ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		Account answer=dao.showBalance(number);
		return answer;
		
	}

	@Override
	public Account deposit(int wallet) throws BankException, ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		return dao.deposit(wallet);
	}
	

	@Override
	public Account withdraw(int acc1) throws BankException, SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub

		return dao.withdraw(acc1);
	}

	@Override
	public void displayDepositDetails(double total, int wallet)
			throws ClassNotFoundException, SQLException, BankException {
		// TODO Auto-generated method stub
		dao.displayDepositDetails(total,wallet);

		
	}

	@Override
	public void withdrawDetails(double d1, int acc1) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		dao.withdrawDetails(d1,acc1);

		
	}

	@Override
	public void storeIntoTransaction(String s, Integer i) {
		// TODO Auto-generated method stub
		dao.storeIntoTransaction(s,i);

	}

	@Override
	public Map<String, Integer> getTransactionInfo() {
		// TODO Auto-generated method stub
		Map<String,Integer>ans=dao.getTransactionInfo();
		
		return ans;
	}



}

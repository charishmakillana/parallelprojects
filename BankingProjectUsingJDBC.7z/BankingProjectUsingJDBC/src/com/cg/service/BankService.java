package com.cg.service;

import java.sql.SQLException;
import java.util.Map;

import com.cg.bankException.BankException;
import com.cg.bean.Account;




public interface BankService {


	void validateName(String custName) throws BankException;

	

	void validateBranch(String branchname) throws BankException;

	void addCustomer(int accountnumber, Account account) throws BankException, ClassNotFoundException, SQLException;

	Account showBalance(int number) throws BankException, ClassNotFoundException, SQLException;

	Account deposit(int wallet)throws BankException, ClassNotFoundException, SQLException;

	Account withdraw(int acc1)throws BankException, SQLException, ClassNotFoundException;

	void displayDepositDetails(double total, int wallet) throws ClassNotFoundException, SQLException, BankException;

	void withdrawDetails(double d1, int acc1) throws SQLException, ClassNotFoundException;

	void storeIntoTransaction(String s, Integer i);

	Map<String, Integer> getTransactionInfo();

	void validatePhoneno(String phoneno) throws BankException;

	

}




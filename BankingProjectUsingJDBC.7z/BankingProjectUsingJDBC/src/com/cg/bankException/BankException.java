package com.cg.bankException;

public class BankException extends Exception {
	
	public BankException(String s)
	{
		super(s);
	}

}

package com.cg.bean;

public class Account {

	private String cus_Name;
	private String mobileNum;
	private String branch;
	@Override
	public String toString() {
		return "Account [cus_Name=" + cus_Name + ", mobileNum=" + mobileNum + ", branch=" + branch + ", balance="
				+ balance + "]";
	}
	public String getCus_Name() {
		return cus_Name;
	}
	public void setCus_Name(String cus_Name) {
		this.cus_Name = cus_Name;
	}
	public String getMobileNum() {
		return mobileNum;
	}
	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public double getBalance() {
		return balance;
	}
	public double setBalance(double balance) {
		return this.balance = balance;
	}
	public Account(String cus_Name, String mobileNum, String branch, double balance) {
		super();
		this.cus_Name = cus_Name;
		this.mobileNum = mobileNum;
		this.branch = branch;
		this.balance = balance;
	}
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	private double balance;
	

}

package com.cg.dao;

import java.sql.SQLException;
import java.util.Map;

import com.cg.bankException.BankException;
import com.cg.bean.Account;



public interface BankDAO {


	Account showBalance(int number) throws SQLException, ClassNotFoundException, BankException;

	void addCustomer(int acntno, Account ab) throws ClassNotFoundException, SQLException;

	Account deposit(int target) throws ClassNotFoundException, SQLException, BankException;

	Account withdraw(int acc1) throws SQLException, ClassNotFoundException, BankException;

	void displayDepositDetails(double total, int target) throws ClassNotFoundException, SQLException, BankException;

	void withdrawDetails(double d1, int acc1) throws SQLException, ClassNotFoundException;

	void storeIntoTransaction(String s, Integer i);

	Map<String, Integer> getTransactionInfo();



}

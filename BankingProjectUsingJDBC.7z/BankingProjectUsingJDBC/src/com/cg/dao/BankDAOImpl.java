package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import com.cg.bankException.BankException;
import com.cg.bean.Account;
import com.cg.util.BankUtil;

public class BankDAOImpl implements BankDAO {
	
	public static Map<String,Integer>map=new HashMap<String,Integer>();

	@Override
	public Account showBalance(int number) throws SQLException,ClassNotFoundException, BankException {
		
		Connection con=BankUtil.connect();
		Statement st=con.createStatement();
		ResultSet res=st.executeQuery("SELECT * FROM ACCOUNTDETAILS WHERE ACCOUNTNO=' "+number+" ' ");
		
		while(res.next())
		{
			int accno=res.getInt(1);
			String customerName=res.getString(2);
			String branch=res.getString(4);
		    String mobileno=res.getString(3);
			double balance =res.getDouble(5);
			Account ab=new Account(customerName,mobileno,branch,balance);
			return ab;		
	}
		con.commit();
		throw new BankException("Invalid account number");
	}

	@Override
	public void addCustomer(int accno, Account ab) throws ClassNotFoundException, SQLException {
		Connection con=BankUtil.connect();
		Statement st=con.createStatement();
		PreparedStatement pst=con.prepareStatement("INSERT INTO ACCOUNTDETAILS VALUES(?,?,?,?,?)");
		pst.setInt(1, accno);
		pst.setString(2, ab.getCus_Name());
		pst.setString(3, ab.getMobileNum());
		pst.setString(4, ab.getBranch());
		pst.setDouble(5, ab.getBalance());
		pst.executeUpdate();
		
	}

	@Override
	public Account deposit(int target) throws ClassNotFoundException, SQLException, BankException {
		
		Connection con=BankUtil.connect();
		Statement st=con.createStatement();
		ResultSet res2 =st.executeQuery("SELECT * FROM ACCOUNT WHERE ACCOUNTNO=' "+target+" ' "); 
			 
		while(res2.next())
		{
			int accno=res2.getInt(1);
			String custName=res2.getString(2);
			String branchname=res2.getString(4);
		    String cellno=res2.getString(3);
			double accountbalance =res2.getDouble(5);
			Account ab=new Account(custName,cellno,branchname,accountbalance);
			return ab;
	}
		con.commit();
		throw new BankException("Invalid account number");
	}

	@Override
	public Account withdraw(int acc1) throws SQLException, ClassNotFoundException, BankException {
		
		Connection con=BankUtil.connect();
		Statement st=con.createStatement();
		ResultSet res5 =st.executeQuery("SELECT * FROM ACCOUNT WHERE ACCOUNTNO=' "+acc1+" ' "); 
			 
		while(res5.next())
		{
			int accno=res5.getInt(1);
			String custName=res5.getString(2);
			String branchname=res5.getString(4);
		    String cellno=res5.getString(3);
			double accountbalance =res5.getDouble(5);
			Account ab=new Account(custName,cellno,branchname,accountbalance);
			return ab;		
	}
		con.commit();
		throw new BankException("Invalid account number");
	}

	@Override
	public void displayDepositDetails(double total, int target) throws ClassNotFoundException, SQLException, BankException {
	
		Connection con=BankUtil.connect();
		Statement st=con.createStatement();
		ResultSet result =st.executeQuery("update ACCOUNT set ACCOUNTBALANCE='"+total+"'where ACCOUNTNO='"+target+"'"); 
		con.commit();
	}
	

	@Override
	public void withdrawDetails(double d1, int acc1) throws SQLException, ClassNotFoundException {
		
		Connection con=BankUtil.connect();
		Statement st=con.createStatement();
		ResultSet rs =st.executeQuery("update ACCOUNT set ACCOUNTBALANCE='"+d1+"'where ACCOUNTNO='"+acc1+"'"); 	 
		con.commit();
	}

	@Override
	public void storeIntoTransaction(String s, Integer i) {
		
		map.put(s, i);
	}

	@Override
	public Map<String, Integer> getTransactionInfo() {
		
		return map;
	}
}


package com.cg.dao;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.bean.Account;

public class BankDAOTest {

	@Test
	public void testShowBalance() {
		Account acnt = new Account();
		acnt.setMobileNum("9876543210");
		String num = acnt.getMobileNum();
		assertEquals("9876543210",num);
	}

}

package com.cg.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entity.Customer;
import com.cg.service.ICustomerService;

@Controller
public class CustomerController {

	@Autowired
	ICustomerService service;
	@Autowired
	Customer cust;
	
	@RequestMapping("/")
	public String getHomePage(Model model) {

		model.addAttribute("customer", new Customer());
		return "homePage";
	}
	
	@RequestMapping("/create.html")
	public String showCreate(Model model) {

		model.addAttribute("customer", new Customer());
		return "create";
	}
	
	@RequestMapping(value="/createAccount")
	public String createCustomer(@ModelAttribute Customer customer,Model model) {
	Customer savedAcc=service.createAcc(customer);
	model.addAttribute("customer",savedAcc);
	return "create";
	}
	
	
	@RequestMapping("/show.html")
	public String showBalance(Model model) {

		model.addAttribute("customer", new Customer());
		return "show";
	}
	
	@RequestMapping("showBal")
	public String showBalance(@ModelAttribute("customer") Customer customer,Model model) {
		Customer cust=null;
		cust=service.findByMobNo(customer.getMobNo());
		model.addAttribute("balance",cust.getBalc());
		return "show";
	}
	
	
	@RequestMapping("/deposit.html")
	public String deposit(Model model) {

		model.addAttribute("customer", new Customer());
		return "deposit";
	}
	
	@RequestMapping(value="/dFund")
	public String deposit(@ModelAttribute("customer") Customer customer,Model model) {
		Customer cust=null;
		service.depositMoney(customer.getMobNo(), customer.getBalc());
		return "homePage";
	}
	
	@RequestMapping("/withdraw.html")
	public String withdraw(Model model) {

		model.addAttribute("customer", new Customer());
		return "withdraw";
	}
	
	@RequestMapping(value="/wFund")
	public String withdraw(@ModelAttribute("customer") Customer customer,Model model) {
		//System.out.println(Mobile_no+"--"+amount.doubleValue());
		service.withdrawMoney(customer.getMobNo(), customer.getBalc());
		return "homePage";
		}
	
	@RequestMapping("/transfer.html")
	public String transfer(Model model) {

		model.addAttribute("customer", new Customer());
		return "transfer";
	}
	
	@RequestMapping(value="/fund")
	public String fundTransfer(@RequestParam String mobNo1,@RequestParam String mobNo2, @RequestParam double amt,Model model) {
	 service.fundTransfer(mobNo1, mobNo2, amt);
	 return "homePage";
	}
	
	
	
	
//	@RequestMapping(value="/delete")
//	public String deleteById(@PathVariable String mobNo,Model model) {
//		service.deleteByMobNo(mobNo);
//		return mobNo +"/n"+"Account Deleted";
//	}
	
	@RequestMapping(value="/viewsAcc")
	public List<Customer> viewCustomers(){
		return service.viewCustomers();
	}
	
//	@RequestMapping(value="/createAccount")
//	public Customer findById(@PathVariable String mobNo,Model model) {
//		customer= service.findByMobNo(mobNo);
	//syso customer.getBal();
//	}
	
	
}

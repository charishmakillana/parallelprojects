package com.cg.dao;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.entity.BankAccount;
import com.cg.exception.BankAccountException;

public class Testcases {
	static BankAccountDAOImpl bankdao=new BankAccountDAOImpl();
	@SuppressWarnings("deprecation")
	@Test
	public void test() throws BankAccountException {
		BankAccount acc=bankdao.showAccountBalance(33678546789l);
	    double bal=acc.getBalance(); 
		assertEquals(20000,bal);
	}

}

package com.cg.entity;



public class BankAccount {
	private String accountType;
	private double balance;
	private long accountNumber;
	public BankAccount(String accountType, double balance, long accountNumber) {
		super();
		this.accountType = accountType;
		this.balance = balance;
		this.accountNumber = accountNumber;
	}
	public BankAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	@Override
	public String toString() {
		return "BankAccount [accountType=" + accountType + ", balance=" + balance + ", accountNumber=" + accountNumber
				+ "]";
	}
	
	}

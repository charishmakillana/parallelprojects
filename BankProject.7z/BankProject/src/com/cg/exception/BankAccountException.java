package com.cg.exception;

public class BankAccountException extends Exception{
	
	
	public BankAccountException(long accNo1) {
		// TODO Auto-generated constructor stub
	}
}

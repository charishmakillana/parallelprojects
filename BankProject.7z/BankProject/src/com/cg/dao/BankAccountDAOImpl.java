package com.cg.dao;

import java.util.HashMap;

import com.cg.entity.BankAccount;
import com.cg.entity.CustomerInfo;
import com.cg.util.BankUtil;

public class BankAccountDAOImpl implements BankAccountDAO{

	@Override
	public long addCustomer(Long acntNo, CustomerInfo customer) {
		BankUtil.addCustomer(acntNo, customer);
		return customer.getCustomeraccountno();
	}

	@Override
	public long addAccount(Long accntNo, BankAccount acnt) {
		BankUtil.addAccount(accntNo, acnt);
		return acnt.getAccountNumber();
	}

	@Override
	public BankAccount AmountDeposit(Long acntNo, double balance) {
		BankAccount account=BankUtil.deposit(acntNo,balance);
		return account;
		
	}

	@Override
	public BankAccount withDrawAmount(Long acntNo, double balance) {
		BankAccount acnt =BankUtil.withdraw(acntNo,balance);
		return acnt;
	}

	@Override
	public BankAccount showAccountBalance(Long acntNo) {
		BankAccount account= BankUtil.showBalance(acntNo);
		return account;
	}

	@Override
	public BankAccount fundTransfer(Long acntNo) {
		BankAccount account= BankUtil.fundTransfer(acntNo);
		return account;
	}

	@Override
	public HashMap<Long, BankAccount> fetchBankAccount() {
		HashMap<Long,BankAccount> map=	BankUtil.fetchAccount();
		return map;
	}



}

package com.cg.dao;

import java.util.HashMap;

import com.cg.entity.BankAccount;
import com.cg.entity.CustomerInfo;



public interface BankAccountDAO {
	public long addCustomer(Long acntNo,CustomerInfo customer);
	public long addAccount(Long accntNo,BankAccount acnt);
	public BankAccount AmountDeposit(Long acntNo,double balance);
	public BankAccount withDrawAmount(Long acntNo,double balance);
	public BankAccount showAccountBalance(Long acntNo);
	public BankAccount fundTransfer(Long acntNo);
	HashMap<Long, BankAccount> fetchBankAccount();

}

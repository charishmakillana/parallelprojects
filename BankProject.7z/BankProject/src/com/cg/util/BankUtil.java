package com.cg.util;

import java.util.HashMap;

import com.cg.entity.BankAccount;
import com.cg.entity.CustomerInfo;



public class BankUtil {
public static HashMap<Long, BankAccount > accountMap=new HashMap<Long, BankAccount >();
	
	static
	{
		accountMap.put(33678546789l,new  BankAccount ("savings a/c",20000,33678546789l));
		accountMap.put(33678556799l,new  BankAccount ("savings a/c",30000,33678556799l));
		accountMap.put(33678566777l,new BankAccount("savings a/c",50000,33678566777l));
		accountMap.put(33678577689l,new BankAccount("savings a/c",10000,33678577689l));
		accountMap.put(33678586796l,new BankAccount("savings a/c",70000,33678586796l));
				
	}
	public static HashMap<Long,CustomerInfo> customerMap=new HashMap<Long,CustomerInfo>();
	
	static
	{
		customerMap.put(33678546789l, new CustomerInfo("Navya",33678546789l,"8555911861","Nellore"));
		customerMap.put(33678556799l, new CustomerInfo("Kavya",33678556799l,"9676329303","Chennai"));
		customerMap.put(33678566777l, new CustomerInfo("Divya",33678566777l,"8985271446","Bangalore"));
		customerMap.put(33678577689l, new CustomerInfo("Hema",33678577689l,"9742850852","Kerala"));
		customerMap.put(33678586796l, new CustomerInfo("Bindu",33678586796l,"912103037","Vizag"));
	}
	public static void addCustomer(Long accno,CustomerInfo c)
	{
		customerMap.put(accno, c);
	}
	public static void addAccount(Long accno,BankAccount a)
	{
		accountMap.put(accno, a);
	}
	public static BankAccount deposit(Long accno,double balance) {
		return accountMap.get(accno);
		
	}
	public static BankAccount withdraw(Long accno,double balance) {
		return accountMap.get(accno);
	}
	public static BankAccount fundTransfer(long accNo)
	{
		return accountMap.get(accNo);
		
	}
	public static BankAccount showBalance(long accNo)
	{
		return accountMap.get(accNo);
		
	}
	public static HashMap<Long,BankAccount> fetchAccount(){
		return accountMap;
	}
	


}

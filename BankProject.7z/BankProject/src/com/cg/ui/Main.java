package com.cg.ui;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.entity.BankAccount;
import com.cg.entity.CustomerInfo;
import com.cg.exception.BankAccountException;
import com.cg.service.BankServiceImpl;
import com.cg.service.IBankService;



public class Main {
	

		static Scanner sc=null;
		static IBankService bankService=null;
		private static double balance;
		
		public static void main(String[] args) throws BankAccountException {
			sc=new Scanner(System.in);
			bankService=new BankServiceImpl();
			int choice=0;
			while(true)
			{
				System.out.println("Welcome to xyz bank");
				System.out.println("1:Create an account\t 2:To show the balance of account\n");
				System.out.println("3:Deposit\t 4:To withdraw Amount\n");
				System.out.println("5:For FundTransfer\n");
				System.out.println("6:EXIT");
				System.out.println("Enter Your Choice");
				choice=sc.nextInt();
				switch(choice)
				{
				case 1:
					createAccount();
					break;
				case 2:
					showBalance();
					break;
				case 3:
					deposit();
					break;
				case 4:
					withdraw();
					break;
				case 5:
					fundTransfer();
					break;
				
				default:
					break;
				}
				
			}
		}

		private static void createAccount() throws BankAccountException{

			System.out.println("enter the customername:");
			String customername=sc.next();
			try
			{
			if(bankService.validateCustomerName(customername))
			{
				
			
					System.out.println("enter the customer mobile number");
					String number=sc.next();
					try
					{
					if(bankService.validateNumber(number))
					{
						System.out.println("enter the customer address");
						String address=sc.next();
						System.out.println("Minimum balance to be deposited to create an account");
						double amount=sc.nextDouble();
						System.out.println("enter the account type");
						String type=sc.next();
						if(amount>3000)
						{
						long accno=(long)(Math.round(Math.random()*10000000+10000000));
						System.out.println(" account created sucessfully"+" "+"account number generated"+" "+accno);
						BankAccount acc=new BankAccount(type,amount,accno);
					    bankService.addAccount(accno, acc);
					    CustomerInfo cus=new CustomerInfo(customername,accno,number,address);
					    bankService.addCustomer(accno, cus);
						}
						else{
							System.out.println("Minimum amount should be 3000 to create account");
						}
						
					}
				}catch(BankAccountException e){
					
				}
			}
			}catch(BankAccountException e){
				
			}

		
		

		}
			
			

			public static void showBalance()
			{
				System.out.println("Enter Amount to get Balance");
				long accno=sc.nextLong();
				String accNo1=String.valueOf(accno);
				try {
				if(bankService.validateAccountno(accNo1)==true)
				{
					HashMap<Long, BankAccount> map=bankService.fetchBankAccount();
					try {
					if(map.containsKey(accno))
					{
					
						BankAccount account=bankService.showAccountBalance(accno);
				double balance=account.getBalance();
				System.out.println("Balance in the Account:"+ balance);
				
				}
					else
					{
						throw new BankAccountException(accno);
					}}catch(BankAccountException e)
					{
						e.getStackTrace();
					}
				}
					
				else
				{
					throw new BankAccountException(accno);
				}
			}catch(BankAccountException e)
				{
				e.getStackTrace();
				}
			}

		private static void deposit() throws BankAccountException {
				System.out.println("Enter the AccountNo");
				long accNo=sc.nextLong();
				String accNo1=String.valueOf(accNo);

				if(bankService.validateAccountno(accNo1)==true)
					
				{
					HashMap<Long, BankAccount> map=bankService.fetchBankAccount();
					try {
					if(map.containsKey(accNo))
					{
					System.out.println("Enter Amount to be Deposited");
					double amount=sc.nextDouble();
					BankAccount acc=bankService.AmountDeposit(accNo,balance);
					double balance1=acc.getBalance();
					double balance=balance1+amount;
					
					String type = "savings";
					BankAccount acc1=new BankAccount(type,balance, accNo);
					System.out.println("Amount Succesfully Deposited:"+acc1);
					
				}else
				{
					throw new BankAccountException(accNo);
				}}catch(BankAccountException e)
				{
					e.getStackTrace();
				}
				}
				else
				{
					System.out.println("Enter the valid AccountNo");
				}
				}
		private static void withdraw() {
			System.out.println("Enter your account number");
			String accno=sc.next();
			String accNo1=String.valueOf(accno);
			try {
			if(bankService.validateAccountno(accNo1)==true)
				
			{
				HashMap<Long, BankAccount> map=bankService.fetchBankAccount();
				try {
				if(map.containsKey(accno))
				{
				System.out.println("Enter Amount to be Withdrawn");
				double amount=sc.nextDouble();
				BankAccount acc=bankService.withDrawAmount(Long.parseLong(accno),balance);
				double bal=acc.getBalance();
				if(amount<(bal-3000))
				{
					double balance=bal-amount;
					String type = "savings";
					BankAccount acc1=new BankAccount(type,balance,Long.parseLong(accno));
					System.out.println("Amount Succesfully Withdrawn ");
					System.out.println("Account Balance:"+" "+balance);
					
				}
			}
				else
				{
					throw new BankAccountException(Long.parseLong(accno));
				}}catch(BankAccountException e)
				{
					e.getStackTrace();
				}
			}
			else
			{
				throw new BankAccountException(Long.parseLong(accno));
			}
		}catch(BankAccountException e)
			{
			e.getStackTrace();
			}
		}

		private static void fundTransfer() {
			System.out.println("Enter the Sender AccountNo");
			long accNo1=sc.nextLong();
			System.out.println("Enter the reciepent AccountNo");
			long accNo2= sc.nextLong();
			String accNo3=String.valueOf(accNo1);
			String accNo4=String.valueOf(accNo2);
			try {
			if((bankService.validateAccountno(accNo3)==true)&&(bankService.validateAccountno(accNo4)==true))
			{
				
				HashMap<Long, BankAccount> map=bankService.fetchBankAccount();
				try {
				if(map.containsKey(accNo1)&&map.containsKey(accNo2))
				{
				System.out.println("Enter Amount to be Transfer");
				double amount=sc.nextDouble();
				BankAccount acc=bankService.fundTransfer(accNo1);
				BankAccount acc1=bankService.fundTransfer(accNo2);
				double bal1=acc.getBalance();
				double bal2=acc.getBalance();
				if(amount<(bal1-500))
				{
					
				
					double balance2=bal2+amount;
					double balance1=bal1-amount;
				    String type = "savings";
				    BankAccount account1=new BankAccount(type,balance1,accNo1);
					BankAccount account2=new BankAccount(type,balance2, accNo2);
					System.out.println("Amount is Successfully Transfered");
					System.out.println("Amount balance in Sender:"+balance1);
					System.out.println("Amount balance in reciepent:"+balance2);
				}
			}else
			{
				throw new BankAccountException(accNo1);
			}
		}catch(BankAccountException e)
			{
			e.getStackTrace();
			}
			}
			else
			{
				throw new BankAccountException(accNo1);
			}
		}catch(BankAccountException e)
			{
			e.getStackTrace();
			}
				
			
		}
			
			
	}



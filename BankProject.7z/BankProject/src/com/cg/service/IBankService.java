package com.cg.service;

import java.util.HashMap;

import com.cg.entity.BankAccount;
import com.cg.entity.CustomerInfo;
import com.cg.exception.BankAccountException;


public interface IBankService {
	public long addCustomer(Long acntNo,CustomerInfo customer);
	public long addAccount(Long acntNo,BankAccount a);
	public BankAccount  AmountDeposit(Long acntNo,double balance);
	public BankAccount withDrawAmount(Long acntNo,double balance);
	boolean validateCustomerName(String customername) throws BankAccountException;
	boolean validateNumber(String number) throws BankAccountException;
	boolean validateAccountno(String acntNo) throws BankAccountException;
	public HashMap<Long, BankAccount> fetchBankAccount();
	public BankAccount showAccountBalance(long accNo);
	public BankAccount fundTransfer(long accNo1);
	

}

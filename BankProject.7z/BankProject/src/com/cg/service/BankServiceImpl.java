package com.cg.service;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.dao.BankAccountDAO;
import com.cg.dao.BankAccountDAOImpl;
import com.cg.entity.BankAccount;
import com.cg.entity.CustomerInfo;
import com.cg.exception.BankAccountException;

public class BankServiceImpl implements IBankService {
	BankAccountDAO bankdao=new BankAccountDAOImpl();

	@Override
	public long addCustomer(Long acntNo, CustomerInfo customer) {
		bankdao.addCustomer(acntNo, customer);
		return customer.getCustomeraccountno();
	}

	@Override
	public long addAccount(Long acntNo, BankAccount account) {
		bankdao.addAccount(acntNo, account);
		return account.getAccountNumber();
	}

	@Override
	public BankAccount AmountDeposit(Long acntNo, double balance) {
		BankAccount account =bankdao.AmountDeposit(acntNo, balance);
		return account;
	}

	@Override
	public BankAccount withDrawAmount(Long acntNo, double balance) {
		BankAccount account =bankdao.withDrawAmount(acntNo, balance);
		return account;
	}

	@Override
	public boolean validateCustomerName(String customername) throws BankAccountException {
		Pattern p=Pattern.compile("[A-z]{1}[a-z]{1,9}");
		Matcher m=p.matcher(customername);
		if(m.matches())
		{
			return true;
		}
		else
			
			System.out.println("enter valid name");
			return false;
	}

	@Override
	public boolean validateNumber(String number) throws BankAccountException {
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(number);
		if(m.matches())
		{
			return true;
		}
		else
			
			System.out.println("enter valid number");
			return false;
	}

	@Override
	public boolean validateAccountno(String acntNo) throws BankAccountException {
		Pattern p=Pattern.compile("[0-9]{11}");
		Matcher m=p.matcher(acntNo);
		if(m.matches())
		{
			return true;
		}
		else
		
			System.out.println("enter valid accno");
			return false;
		
		
	}

	@Override
	public HashMap<Long, BankAccount> fetchBankAccount() {
		HashMap<Long,BankAccount> map=bankdao.fetchBankAccount();
		return map;
	}

	@Override
	public BankAccount showAccountBalance(long accNo) {
		BankAccount account=bankdao.showAccountBalance(accNo);
		return account;
		
	}

	@Override
	public BankAccount fundTransfer(long accNo1) {
		BankAccount account=bankdao.fundTransfer(accNo1);
		return account;
	}

}
